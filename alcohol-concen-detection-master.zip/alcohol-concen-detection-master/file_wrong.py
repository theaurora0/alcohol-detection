import os
from utils.data_loading_utils import wrong_file
from utils.common import *

# file_rename("Absolute_Data/7_8/07-27_1", "7_8.csv")

path = "Absolute_Data/7_3/07-29_6"  # 有问题的文件夹的相对路径
concentrations = "0.735"  # 有问题的浓度，用+号隔开
re = True  # 当为false（复制）时不删除错误浓度，当为True（剪切）时删除错误浓度。
wrong_file(path, concentrations, re)

# path = "Absolute_Data"
#
# name_paths = os.listdir(path)
#
# for name_path in name_paths:
#     date_paths = os.listdir(os.path.join(path, name_path))
#     for date_path in date_paths:
#         concentrations = os.listdir(os.path.join(path, name_path, date_path))
#         for concentration in concentrations:
#             old_name = os.path.join(path, name_path, date_path, concentration)
#             if concentration[:5] == "0.810":
#                 new_name = os.path.join(path, name_path, date_path, "0.100{}".format(concentration[5:]))
#                 os.rename(old_name, new_name)
#             if concentration[:5] == "0.820":
#                 new_name = os.path.join(path, name_path, date_path, "0.200{}".format(concentration[5:]))
#                 os.rename(old_name, new_name)
