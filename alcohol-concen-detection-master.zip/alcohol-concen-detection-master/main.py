import argparse
import pygame
import time
import os

T = True


def parse_args():
    parse = argparse.ArgumentParser()

    parse.add_argument('--group', default='1_5', type=str, help='operator code')
    parse.add_argument('--num', default=1, type=int, help='The num th group of data of the day')
    parse.add_argument('--concentration', default=[0.5], type=float, help='Alcohol concentration')
    parse.add_argument('--th_1550', default=1.2, type=float, help='the num of threshold value 1550')
    parse.add_argument('--th_1362', default=1.2, type=float, help='the num of threshold value 1362')
    parse.add_argument('--num_laser', default=2, type=int, help='the num of the lasers')

    parse.add_argument('--para', default="chan_2_0+chan_2_1+chan_2_2+chan_2_3", type=str,
                       help='Network training parameters')
    parse.add_argument('--test_groups', default="1_5", type=str, help='The second set of training parameters')
    parse.add_argument('--save', default=False, type=bool, help='save or not')

    args = parse.parse_args()
    return args


def play_music(file_path, loop=True):
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play(loops=-1 if loop else 0)


if __name__ == "__main__":
    args = parse_args()
    pygame.init()
    pygame.mixer.init()
    # 数据采集
    for n in range(len(args.concentration)):
        # play_music("music/1_{}.mp3".format(n + 1), loop=False)
        # time.sleep(1.5)
        os.system(
            "D:\miniconda3\envs\GD\python dual_wavelength_data_acquisition.py --group {} --num {} --concentration {} --th_1550 {} --th_1362 {} --num_laser {}".format(
                args.group, args.num, args.concentration[n], args.th_1550, args.th_1362, args.num_laser))
    # 结果预测
    if T:
        os.system(
            "D:\miniconda3\envs\GD\python test.py --para {} --test_groups {} --save {}".format(args.para,
                                                                                               args.test_groups,
                                                                                               args.save))
