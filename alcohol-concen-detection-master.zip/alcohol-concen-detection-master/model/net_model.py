import torch.nn as nn
import torch
from collections import OrderedDict


# # Define net model
# class MLP(nn.Module):
#     def __init__(self, num_inputs, num_hiddens, dropout):
#         super().__init__()
#         # self.save_hyperparameters()
#         self.net = nn.Sequential(
#             # hidden layer
#             nn.Linear(num_inputs, num_hiddens),
#             nn.ReLU(),
#             nn.Dropout(dropout),
#             # output layer
#             nn.Linear(num_hiddens, 1),
#         )
#
#     def forward(self, X):
#         out = self.net(X)
#         return out.squeeze(0).squeeze(0)

class bn(nn.Module):
    def __init__(self, ns=0.1):
        super(bn, self).__init__()
        self.net = nn.LeakyReLU(ns)

    def forward(self, x):
        x = (x - torch.mean(x)) / torch.std(x)
        x = self.net(x)
        return x


class res_block(nn.Module):
    def __init__(self, input_num, output_num, ns=0.1, bias=True):
        super(res_block, self).__init__()
        self.linear_1 = nn.Linear(input_num, output_num, bias)
        self.linear_2 = nn.Linear(output_num, output_num, bias)
        if input_num != output_num:
            self.linear_3 = nn.Linear(input_num, output_num, bias)
        else:
            self.linear_3 = None
        self.bn = bn(ns)

    def forward(self, x):
        y = self.bn(self.linear_1(x))
        y = self.linear_2(y)

        if self.linear_3:
            x = self.linear_3(x)

        return x + y


# Define net model
class MLP(nn.Module):
    def __init__(self, layer_num, dropout_num, res=True, bias=True, BN=True, ns=0.1):
        super(MLP, self).__init__()
        # self.save_hyperparameters()
        num = len(layer_num) - 1
        self.net = nn.Sequential()
        for i in range(num):
            if i < (num - 1):
                if res:
                    self.net.add_module("layer_{}".format(i), res_block(layer_num[i], layer_num[i + 1], ns, bias=bias))
                else:
                    self.net.add_module("layer_{}".format(i), nn.Linear(layer_num[i], layer_num[i + 1], bias=bias))
                if BN:
                    self.net.add_module("BN_{}".format(i), bn(ns=ns))
                else:
                    self.net.add_module("LeakyReLU_{}".format(i), nn.LeakyReLU(negative_slope=ns))
                self.net.add_module("Dropout_{}".format(i), nn.Dropout(dropout_num[i]))
            else:
                self.net.add_module("layer_{}".format(i), nn.Linear(layer_num[i], layer_num[i + 1], bias=bias))

    def forward(self, X):
        out = self.net(X)
        return out.squeeze(0).squeeze(0)
