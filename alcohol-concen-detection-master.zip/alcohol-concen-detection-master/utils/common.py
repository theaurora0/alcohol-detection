import numpy as np
import os


def get_path(path):
    folder = os.path.exists(path)

    if not folder:
        os.makedirs(path)


def file_rename(path, r_name):
    # path = "Absolute_Data/7_1"
    # r_name = "7_1.csv"
    date_files = os.listdir(path)
    for date_file in date_files:
        concentration_files = os.listdir(os.path.join(path, date_file))
        for concentration_file in concentration_files:
            old_name = os.path.join(path, date_file, concentration_file)
            new_name = os.path.join(path, date_file, f"{concentration_file[:-8]}_{r_name}")
            os.rename(old_name, new_name)
