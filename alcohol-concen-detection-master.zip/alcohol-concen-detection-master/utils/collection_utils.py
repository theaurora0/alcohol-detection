import os
from mcculw import ul
from mcculw.enums import InterfaceType, DigitalIODirection


###############################################################################
# 1_1. MCC DAQ device detection and configuration
###############################################################################
def config_first_detected_device(board_num, dev_id_list=None):
    """Adds the first available device to the UL.  If a types_list is specified,
    the first available device in the types list will be add to the UL.

    Parameters
    ----------
    board_num : int
        The board number to assign to the board when configuring the device.

    dev_id_list : list[int], optional
        A list of product IDs used to filter the results. Default is None.
        See UL documentation for device IDs.
    """
    ul.ignore_instacal()
    devices = ul.get_daq_device_inventory(InterfaceType.ANY)
    if not devices:
        raise Exception("Error: No DAQ devices found")

    print("Found", len(devices), "DAQ device(s):")
    for device in devices:
        print(
            "  ",
            device.product_name,
            " (",
            device.unique_id,
            ") - ",
            "Device ID = ",
            device.product_id,
            sep="",
        )

    device = devices[0]
    if dev_id_list:
        device = next(
            (device for device in devices if device.product_id in dev_id_list),
            None,
        )
        if not device:
            err_str = "Error: No DAQ device found in device ID list: "
            err_str += ",".join(str(dev_id) for dev_id in dev_id_list)
            raise Exception(err_str)

    # Add the first DAQ device to the UL with the specified board number
    ul.create_daq_device(board_num, device)


def digital_out(dio_info, board_num, port_value):
    # Find the first port that supports input, defaulting to None
    # if one is not found.
    port = next(
        (port for port in dio_info.port_info if port.supports_output), None
    )
    if not port:
        raise Exception(
            "Error: The DAQ device does not support " "digital output"
        )

    # If the port is configurable, configure it for output.
    if port.is_port_configurable:
        ul.d_config_port(board_num, port.type, DigitalIODirection.OUT)

    print("Setting", port.type.name, "to", port_value)

    # Output the value to the port
    ul.d_out(board_num, port.type, port_value)
