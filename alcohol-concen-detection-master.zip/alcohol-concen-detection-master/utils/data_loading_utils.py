import os
import shutil
import numpy as np
import pandas as pd
import torch
from torch.utils import data
from .common import get_path


def data_process(path_1, path_2, a=0, b=8, c=8, d=16):
    get_path(path_2)
    date_files = os.listdir(path_1)
    for date_file in date_files:
        concentration_files = os.listdir(os.path.join(path_1, date_file))
        if not ("0.810_{}.csv".format(path_1[-3:]) in concentration_files):
            raise Exception("该文件夹下没有0.810浓度的数据，无法处理！")
        data_max = np.array(
            pd.read_csv(os.path.join(path_1, date_file, "0.810_{}.csv".format(path_1[-3:])), header=None,
                        index_col=0)).astype(float)
        data_max = np.append(data_max[a:b], data_max[c:d])
        for concentration_file in concentration_files:
            if concentration_file == "0.810_{}.csv".format(path_1[-3:]):
                continue
            concentration = concentration_file[:-4]
            data_now = np.array(
                pd.read_csv(os.path.join(path_1, date_file, concentration_file), header=None, index_col=0)).astype(
                float)
            data_now = np.append(data_now[a:b], data_now[c:d])
            signal = data_now / data_max
            # for i in range(len(signal)):
            #     if signal[i] > 1_1:
            #         signal[i] = 1_1 / signal[i]
            df = pd.DataFrame(signal)
            df.to_csv(os.path.join(path_2, f"{concentration}.csv"), header=False)
    # train_files = os.listdir(path_2)
    # if not ("0.800.csv" in train_files):
    #     signal = np.ones([16, 1_1])
    #     df = pd.DataFrame(signal)
    #     df.to_csv(os.path.join(path_2, f"0.810.csv"), header=False)


def data_process_(path_1, path_2, a=0, b=8, c=8, d=16):
    get_path(path_2)
    date_files = os.listdir(path_1)
    for date_file in date_files:
        concentration_files = os.listdir(os.path.join(path_1, date_file))
        if not ("0.810_{}.csv".format(path_1[-3:]) in concentration_files):
            raise Exception("该文件夹下没有0.810浓度的数据，无法处理！")

        if not ("0.820_{}.csv".format(path_1[-3:]) in concentration_files):
            raise Exception("该文件夹下没有0.820浓度的数据，无法处理！")

        data_max_810 = np.array(
            pd.read_csv(os.path.join(path_1, date_file, "0.810_{}.csv".format(path_1[-3:])), header=None,
                        index_col=0)).astype(float)
        data_max_810 = np.append(data_max_810[a:b], data_max_810[c:d])

        data_max_820 = np.array(
            pd.read_csv(os.path.join(path_1, date_file, "0.820_{}.csv".format(path_1[-3:])), header=None,
                        index_col=0)).astype(float)
        data_max_820 = np.append(data_max_820[a:b], data_max_820[c:d])

        for concentration_file in concentration_files:
            if (concentration_file == "0.810_{}.csv".format(path_1[-3:])) and (
                    concentration_file == "0.820_{}.csv".format(path_1[-3:])):
                continue
            concentration = concentration_file[:-4]
            data_now = np.array(
                pd.read_csv(os.path.join(path_1, date_file, concentration_file), header=None, index_col=0)).astype(
                float)
            data_now = np.append(data_now[a:b], data_now[c:d])

            signal_810 = data_now / data_max_810
            signal_820 = data_now / data_max_820
            # for i in range(len(signal)):
            #     if signal[i] > 1_1:
            #         signal[i] = 1_1 / signal[i]
            df_810 = pd.DataFrame(signal_810)
            df_810.to_csv(os.path.join(path_2, f"{concentration}_810.csv"), header=False)

            df_820 = pd.DataFrame(signal_820)
            df_820.to_csv(os.path.join(path_2, f"{concentration}_820.csv"), header=False)
    # train_files = os.listdir(path_2)
    # if not ("0.800.csv" in train_files):
    #     signal = np.ones([16, 1_1])
    #     df = pd.DataFrame(signal)
    #     df.to_csv(os.path.join(path_2, f"0.810.csv"), header=False)


def data_process_1(path_1, path_2, a=0, b=8, c=8, d=16):
    get_path(path_2)
    date_files = os.listdir(path_1)
    for date_file in date_files:
        concentration_files = os.listdir(os.path.join(path_1, date_file))
        if (not ("0.100_{}.csv".format(path_1[-3:]) in concentration_files)) and (
                not ("0.200_{}.csv".format(path_1[-3:]) in concentration_files)):
            raise Exception("该文件夹下既没有0.100浓度的数据，也没有0.200浓度的数据，无法处理！")
        elif ("0.100_{}.csv".format(path_1[-3:]) in concentration_files) and (
                "0.200_{}.csv".format(path_1[-3:]) in concentration_files):

            data_max_1 = np.array(
                pd.read_csv(os.path.join(path_1, date_file, "0.100_{}.csv".format(path_1[-3:])), header=None,
                            index_col=0)).astype(float)
            data_max_1 = np.append(data_max_1[a:b], data_max_1[c:d])

            data_max_2 = np.array(
                pd.read_csv(os.path.join(path_1, date_file, "0.200_{}.csv".format(path_1[-3:])), header=None,
                            index_col=0)).astype(float)
            data_max_2 = np.append(data_max_2[a:b], data_max_2[c:d])

            for concentration_file in concentration_files:
                if (concentration_file == "0.100_{}.csv".format(path_1[-3:])) or (
                        concentration_file == "0.200_{}.csv".format(path_1[-3:])):
                    continue
                concentration = concentration_file[:-4]
                data_now = np.array(
                    pd.read_csv(os.path.join(path_1, date_file, concentration_file), header=None, index_col=0)).astype(
                    float)
                data_now = np.append(data_now[a:b], data_now[c:d])

                signal_1 = data_now / data_max_1
                signal_2 = data_now / data_max_2

                df_1 = pd.DataFrame(signal_1)
                df_1.to_csv(os.path.join(path_2, f"{concentration}_100.csv"), header=False)

                df_2 = pd.DataFrame(signal_2)
                df_2.to_csv(os.path.join(path_2, f"{concentration}_200.csv"), header=False)
        elif ("0.100_{}.csv".format(path_1[-3:]) in concentration_files) and (not (
                "0.200_{}.csv".format(path_1[-3:]) in concentration_files)):

            data_max_1 = np.array(
                pd.read_csv(os.path.join(path_1, date_file, "0.100_{}.csv".format(path_1[-3:])), header=None,
                            index_col=0)).astype(float)
            data_max_1 = np.append(data_max_1[a:b], data_max_1[c:d])

            for concentration_file in concentration_files:
                if concentration_file == "0.100_{}.csv".format(path_1[-3:]):
                    continue
                concentration = concentration_file[:-4]
                data_now = np.array(
                    pd.read_csv(os.path.join(path_1, date_file, concentration_file), header=None, index_col=0)).astype(
                    float)
                data_now = np.append(data_now[a:b], data_now[c:d])

                signal_1 = data_now / data_max_1

                df_1 = pd.DataFrame(signal_1)
                df_1.to_csv(os.path.join(path_2, f"{concentration}_100.csv"), header=False)

        elif (not ("0.100_{}.csv".format(path_1[-3:]) in concentration_files)) and (
                "0.200_{}.csv".format(path_1[-3:]) in concentration_files):

            data_max_2 = np.array(
                pd.read_csv(os.path.join(path_1, date_file, "0.200_{}.csv".format(path_1[-3:])), header=None,
                            index_col=0)).astype(float)
            data_max_2 = np.append(data_max_2[a:b], data_max_2[c:d])

            for concentration_file in concentration_files:
                if concentration_file == "0.200_{}.csv".format(path_1[-3:]):
                    continue
                concentration = concentration_file[:-4]
                data_now = np.array(
                    pd.read_csv(os.path.join(path_1, date_file, concentration_file), header=None, index_col=0)).astype(
                    float)
                data_now = np.append(data_now[a:b], data_now[c:d])

                signal_2 = data_now / data_max_2

                df_2 = pd.DataFrame(signal_2)
                df_2.to_csv(os.path.join(path_2, f"{concentration}_200.csv"), header=False)


def data_iter(path, batch_size, is_train):
    label_list = []
    feature_list = []
    files = os.listdir(path)
    for file in files:
        label_list.append(file[:-12])
        feature = np.array(
            pd.read_csv(os.path.join(path, file), header=None, index_col=0))
        feature_list.append(feature.T)
    label_list = np.array(label_list)
    feature_list = np.array(feature_list)
    label_list = label_list.astype(np.float32)
    feature_list = feature_list.astype(np.float32)
    features = torch.from_numpy(feature_list)
    labels = torch.from_numpy(label_list)
    dataset = data.TensorDataset(features, labels)

    return data.DataLoader(dataset, batch_size, shuffle=is_train)


def wrong_file(path_src, concentrations, re=False):
    path_new = f"Absolute_Data/wrong_data/{path_src[14:]}"
    get_path(path_new)
    for concentration in concentrations.split("+"):
        shutil.copy(f"{path_src}/{concentration}_{path_src[14:17]}.csv", path_new)
        if re:
            os.remove(f"{path_src}/{concentration}_{path_src[14:17]}.csv")
