import json
import argparse
import shutil
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib

matplotlib.rc("font", family='KaiTi')

import torch
from torch import nn

from model import MLP
from utils.data_loading_utils import data_process, data_process_, data_process_1, data_iter

# Get GPU or CPU device for trainingS
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using {device} for training")


def parse_args(s):
    parse = argparse.ArgumentParser()
    parse.add_argument('--para', default=s, type=str, help='Network training parameters')
    parse.add_argument('--test_groups', default="9_3", type=str, help='The second set of training parameters')
    parse.add_argument('--save', default=False, type=bool, help='save or not')
    args = parse.parse_args()
    return args


if __name__ == "__main__":
    s = [
        "chan_1550_1362_7_1_1+chan_1550_1362_7_1_2+chan_1550_1362_7_1_3+chan_1550_1362_7_1_4+chan_1550_1362_7_2_1+chan_1550_1362_7_2_2+chan_1550_1362_7_2_3+chan_1550_1362_7_2_4",
        "chan_1550_7_1_1+chan_1550_7_1_2+chan_1550_7_1_3+chan_1550_7_1_4+chan_1550_7_2_1+chan_1550_7_2_2+chan_1550_7_2_3+chan_1550_7_2_4",
        "chan_1362_7_1_1+chan_1362_7_1_2+chan_1362_7_1_3+chan_1362_7_1_4+chan_1362_7_2_1+chan_1362_7_2_2+chan_1362_7_2_3+chan_1362_7_2_4"]
    args = parse_args(s[0])  # 两个激光器均正常：0 ，1550激光器正常：1， 1362激光器正常：2
    label = []
    value = [[], [], [], [], [], [], [], []]
    i = 0
    for parameter_name in args.para.split("+"):
        path = "parameter_path/{}.pth".format(parameter_name)

        filename = open('parameter_path/para_intro.json', 'r')
        para = filename.read()
        para = json.loads(para)
        para = para[parameter_name]
        print("res:{},layer:{}, BN:{}, negative:{}, dropout:{}, parameter_sum:{}".format(para["res"], para["layer"],
                                                                                         para["BatchNorm"],
                                                                                         para["negative_relu"],
                                                                                         para["dropout"],
                                                                                         para["parameter_sum"]))
        print("lr:{}, epochs:{}, train_groups:{}, test_groups:{}, 1550_chan:{}, 1360_chan:{}".format(para["lr"],
                                                                                                     para["epochs"],
                                                                                                     para[
                                                                                                         "train_groups"],
                                                                                                     para[
                                                                                                         "test_groups"],
                                                                                                     para["1550_chan"],
                                                                                                     para["1360_chan"]))
        print("min_loss:{}".format(para["min_loss"]))
        print("train_loss:{}".format(para["train_loss"]))
        print("test_loss:{}".format(para["test_loss"]))

        layer_num = para["layer"]
        dropout_num = para["dropout"]
        BN = para["BatchNorm"]
        ns = para["negative_relu"]
        res = para["res"]
        model = MLP(layer_num, dropout_num, res=res, BN=BN, ns=ns).to(device)
        if device == "cpu":
            model.load_state_dict(torch.load(path, map_location="cpu"))
        else:
            model.load_state_dict(torch.load(path))
        # Use MSE loss function
        loss_fn = nn.MSELoss()

        a, b, c, d = para["1550_chan"][0], para["1550_chan"][1], para["1360_chan"][0], para["1360_chan"][1]
        test_groups = args.test_groups
        net_test_path = "Relative_Data/test"
        shutil.rmtree(net_test_path)
        for test_group in test_groups.split('+'):
            data_test_path = "Absolute_Data/{}".format(test_group)
            data_process_1(data_test_path, net_test_path, a, b, c, d)
        test_iter = data_iter(path="Relative_Data/test", batch_size=1, is_train=False)

        # 展示预测结果
        model.eval()

        test_loss = 0
        with torch.no_grad():
            loss_num = []
            for count, (X, y) in enumerate(test_iter):
                X, y = X.to(device), y.to(device)
                y_hat = model(X)
                if i == 0:
                    label.append(y.item() * 100)
                value[i].append(y_hat.item() * 100)
                dif = np.abs(y_hat.detach().cpu().item() - y.detach().cpu().item()) * 100
                loss_num.append(dif)
                print("测量值: {:.3f}, 预测值: {:.3f}, 误差: {:.6f}".format(y.detach().cpu().item() * 100,
                                                                            y_hat.detach().cpu().item() * 100, dif))
                # if count == 30:
                #     break
            print("均值:{} 方差:{}".format(np.mean(loss_num), np.std(loss_num)))
        i += 1

    label = np.array(label)
    value = np.array(value)

    for i in range(value.shape[0]):
        for j in range(value.shape[1]):
            if value[i, j] > 80:
                value[i, j] = 80
            if value[i, j] < 30:
                value[i, j] = 30
    label = np.around(label, 1)
    value = np.around(value, 1)

    value_mean = np.around(value.mean(axis=0), 1)
    value_std = np.around(value.std(axis=0), 1)

    # # 绘制柱状图
    # x = np.arange(value.shape[1])
    # plt.figure(figsize=(2, 5))
    # # plt.figure(figsize=(15, 8))
    # ax = plt.axes()
    # ax.set_facecolor("white")
    # bar_width = 0.2
    # plt.bar(x, label, bar_width, color="red", label="真实值")
    # plt.bar(x + bar_width, value_mean, bar_width, color="b", label="预测均值")
    # plt.ylabel("浓度(%)")
    # plt.legend(loc=(0, 1))
    # xl = []
    # for i in range(value.shape[1]):
    #     xl.append("样品{}".format(i + 1))
    # plt.xticks(x + bar_width / 2, xl)
    # plt.grid(alpha=0.3)
    # plt.show()

    # # 绘制柱状图
    # x = np.arange(5) + 1
    # plt.figure(figsize=(5, 5))
    # # plt.figure(figsize=(15, 8))
    # ax = plt.axes()
    # ax.set_facecolor("white")
    # bar_width = 0.2
    # xl = ["标准值"]
    # plt.bar(x[0], label, bar_width, color="red", label="真实值")
    # for i in range(4):
    #     plt.bar(x[i+1] + bar_width, value[i], bar_width, color="b", label="预测值{}".format(i + 1))
    #     xl.append("预测值{}".format(i + 1))
    #
    # plt.ylabel("浓度(%)")
    # plt.legend(loc=(0, 1))
    # plt.xticks(x + bar_width / 2, xl)
    # plt.grid(alpha=0.3)
    # plt.show()

    # 绘制柱状图(带误差棒)
    # x = np.arange(value.shape[1])
    # # plt.figure(figsize=(15, 8))
    # plt.figure(figsize=(4, 5))
    # bar_width = 0.2
    # for n in range(value.shape[1]):
    #     plt.subplot(1, value.shape[1], n + 1)
    #     plt.ylim((value_mean[n] - 3, value_mean[n] + 3))
    #     plt.bar(x[n], label[n], bar_width, color="red", label="标准值")
    #     error_params = dict(elinewidth=2, ecolor='orange', capsize=5)  # 设置误差标记参数
    #     plt.bar(x[n] + bar_width, value_mean[n], bar_width, yerr=value_std[n], error_kw=error_params, color="b",
    #             label="预测均值")
    #     plt.xlabel("样品{}".format(n + 1))
    #     if n == 0:
    #         plt.ylabel("浓度(%)")
    #         plt.legend(loc=(0, 1))
    #     plt.grid(alpha=0.3)
    #     plt.xticks([])
    # plt.subplots_adjust(wspace=2, hspace=1)
    # plt.show()

    # # 绘制折线图
    # x = np.arange(1, 5, 1)
    # label_T = np.array([label, label, label, label]).T
    # value_T = value.T
    # plt.figure(figsize=(5, 5))
    # plt.ylim(33, 83)
    # for i in range(label_T.shape[0]):
    #     plt.plot(x, label_T[i], "r-")
    #     plt.plot(x, value_T[i], "b.-")
    #
    # plt.show()

    error_1 = np.around(abs((value[0] + value[1] + value[2] + value[3]) / 4 - 50), 1)
    error_2 = np.around(abs((value[4] + value[5] + value[6] + value[7]) / 4 - 50), 1)
    # 绘制表格
    error_data = np.around(np.abs(value_mean - label), 3)
    print(np.std(error_data))
    s_num = np.arange(value.shape[1])
    s_num = map(str, s_num + 1)
    data = {"真实值": label, "预测值1": value[0], "预测值2": value[1], "预测值3": value[2],
            "预测值4": value[3], "第一组误差": error_1, "预测值5": value[4], "预测值6": value[5], "预测值7": value[6],
            "预测值8": value[7], "第二组误差": error_2}
    df = pd.DataFrame(data)
    # 创建一个表格图片
    fig, ax = plt.subplots(figsize=(10, 8))
    ax.axis('off')  # 隐藏坐标轴

    table = ax.table(cellText=df.values, colLabels=df.columns, cellLoc='center', loc='center')

    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1.2, 1.5)  # 调整表格大小

    plt.savefig("table_picture//1.jpg")
    plt.show()

    if args.save:
        data_r = np.append([label], value, axis=0)
        data_r_T = data_r.T
        df = pd.DataFrame(data_r_T)
        df.to_csv(f"Results\\{args.para}_group_{args.test_groups}.csv")
