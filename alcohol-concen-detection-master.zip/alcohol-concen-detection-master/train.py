import time
import json
import shutil
import numpy as np

import torch
from torch import nn

from model import MLP
from utils.data_loading_utils import data_process, data_process_, data_process_1, data_iter

a, b, c, d = 0, 0, 8, 16  # 选择增益
parameter_name = "chan_1362_7_3_2"  # 参数文件名称
link_parameter = None  # 对已有参数继续训练
train_groups = "7_2"  # 训练集选择
test_groups = "7_7+7_8"  # 测试集选择
T = "train"  # 以训练集的最小损失函数值还是测试集的最小损失函数值作为训练目标
epochs = 300  # 训练轮数
lr = 1e-5  # 损失函数值
layer_num = [b + d - a - c, 48, 48, 1]  # 网络层数以及各层训练参数
dropout_num = [0, 0, 0, 0]  # dropout各层设置
BN = True  # 是否设置BatchNorm层
res = True  # 是否使用残差网络
ns = 0.1  # Leakyrelu在负半轴斜率
process = True  # 是否重新设置训练集和测试集

if process:
    net_train_path = "Relative_Data/train"
    shutil.rmtree(net_train_path)
    for train_group in train_groups.split('+'):
        data_train_path = "Absolute_Data/{}".format(train_group)
        data_process_1(data_train_path, net_train_path, a, b, c, d)

    net_test_path = "Relative_Data/test"
    shutil.rmtree(net_test_path)
    for test_group in test_groups.split('+'):
        data_test_path = "Absolute_Data/{}".format(test_group)
        data_process_1(data_test_path, net_test_path, a, b, c, d)

# Get GPU or CPU device for trainingS
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using {device} for training")

if link_parameter == None:
    model = MLP(layer_num, dropout_num, res=res, BN=BN, ns=ns).to(device)
else:
    model = MLP(layer_num, dropout_num, res=res, BN=BN, ns=ns).to(device)
    if device == "cpu":
        model.load_state_dict(torch.load("parameter_path/{}.pth".format(link_parameter), map_location="cpu"))
    else:
        model.load_state_dict(torch.load("parameter_path/{}".format(link_parameter)))

parameter_sum = sum(p.numel() for p in model.parameters())

# Use MSE loss function
loss_fn = nn.MSELoss()
loss_fn = loss_fn.to(device)

# Set learning rate and optimizer
optimizer = torch.optim.Adam(model.parameters(), lr)


# Define train process
def train(train_iter, model, loss_fn, optimizer):
    data_size = len(train_iter.dataset)

    model.train()
    # train_loss = 0
    average_error = 0
    for count, (X, y) in enumerate(train_iter):
        batch_size = len(X)

        # Transfer data to GPU/CPU
        X, y = X.to(device), y.to(device)
        # print(X)

        # Compute prediction value
        y_hat = model(X)
        # Compute prediction error
        loss = loss_fn(y_hat, y)
        average_error += abs((y.detach().cpu() - y_hat.detach().cpu()).item())

        # Zero the previous gradient
        optimizer.zero_grad()
        # Backpropagation calculates the new gradient
        loss.backward()
        # Update the parameters
        optimizer.step()
        # train_loss += loss.item()
    average_error = (average_error / data_size) * 100
    print(f"训练误差均值：{average_error:.3f}")
    return average_error


# Define test process
def test(test_iter, model, loss_fn):
    data_size = len(test_iter.dataset)
    batch_nums = len(test_iter)

    model.eval()
    # test_loss = 0
    average_error = 0
    with torch.no_grad():
        for X, y in test_iter:
            X, y = X.to(device), y.to(device)
            y_hat = model(X)
            # test_loss += loss_fn(y_hat, y).item()
            average_error += abs((y.detach().cpu() - y_hat.detach().cpu()).item())

        # test_loss /= batch_nums
        average_error = (average_error / data_size) * 100
        print(f"测试误差均值：{average_error:.3f}")
        # print(f"\nTest Error: \n" f"Avg loss: {test_loss:>8f} \n")
        return average_error


# 加载数据
train_iter = data_iter(path="Relative_Data/train", batch_size=1, is_train=True)
test_iter = data_iter(path="Relative_Data/test", batch_size=1, is_train=False)

# 训练
min_loss = 10000
train_loss_t = 0
test_loss_t = 0
loss_list = []
for t in range(epochs):
    print(f"Epoch {t + 1}\n-------------------------------")
    train_loss = train(train_iter, model, loss_fn, optimizer)
    test_loss = test(test_iter, model, loss_fn)
    loss_list.append(train_loss)
    # 保存最好参数
    if T == "test":
        if test_loss < min_loss:
            torch.save(model.state_dict(), "parameter_path\\{}.pth".format(parameter_name))
            min_loss = test_loss
            test_loss_t = test_loss
            train_loss_t = train_loss
    else:
        if train_loss < min_loss:
            torch.save(model.state_dict(), "parameter_path\\{}.pth".format(parameter_name))
            min_loss = train_loss
            test_loss_t = test_loss
            train_loss_t = train_loss

with open('parameter_path/para_intro.json', 'r') as filename:
    para = filename.read()
    para = json.loads(para)
    para[parameter_name] = {"layer": layer_num, "BatchNorm": BN, "negative_relu": ns, "dropout": dropout_num,
                            "parameter_sum": parameter_sum,
                            "lr": lr, "res": res,
                            "epochs": epochs, "train_groups": train_groups, "test_groups": test_groups,
                            "1550_chan": [a, b], "1360_chan": [c, d], "min_loss": T, "train_loss": train_loss_t,
                            "test_loss": test_loss_t}
    para = json.dumps(para, indent=4)
    filename = open('parameter_path/para_intro.json', 'w')
    filename.write(para)
    filename.close()

# import os
# import pandas as pd
#
# df = pd.DataFrame(np.array(loss_list).ravel(order="F"))
# df.to_csv("loss_list.csv", header=False)
