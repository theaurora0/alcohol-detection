import os
import sys
import time
import numpy as np
import pandas as pd
import pygame
import argparse
from datetime import datetime

from ctypes import cast, POINTER, c_double
from mcculw import ul
from mcculw.enums import ScanOptions, DigitalIODirection
from mcculw.device_info import DaqDeviceInfo

from utils.common import get_path
from utils.collection_utils import config_first_detected_device


def parse_args():
    parse = argparse.ArgumentParser()
    parse.add_argument('--group', default='9_3', type=str, help='operator code')
    parse.add_argument('--num', default=1, type=int, help='The num th group of data of the day')
    parse.add_argument('--concentration', default=0.500, type=float, help='Alcohol concentration')
    parse.add_argument('--th_1550', default=1.2, type=float, help='the num of threshold value 1550')
    parse.add_argument('--th_1362', default=1.2, type=float, help='the num of threshold value 1362')
    parse.add_argument('--num_laser', default=2, type=int, help='the num of the lasers')
    args = parse.parse_args()
    return args


if __name__ == "__main__":
    pygame.init()
    pygame.mixer.init()


    def play_music(file_path, loop=True):
        pygame.mixer.music.load(file_path)
        pygame.mixer.music.play(loops=-1 if loop else 0)


    def stop_music():
        pygame.mixer.music.stop()


    #########################################################
    # 文件夹命名规则，文件分为绝对数据与相对数据。绝对数据是探测时的数据，其下面起的一级文件为组别（1_1, 2_1组分别代表艳娜、润秋所测的第一组数据，以此类推艳娜的第二组数据就是1_2）、
    # 二级文件名为日期、三级文件名为浓度，每个日期下都需要测一个纯酒精的数据，文件名设置为0.810
    #########################################################
    args = parse_args()
    group = args.group
    date = datetime.now().strftime("%m-%d")
    num = args.num  # 每天内的第几组数据，每打开一次设备就算另外一组需要重新测一遍0.800的
    date = "{}_{}".format(date, num)
    concentration = args.concentration
    th = [args.th_1362, args.th_1550]

    # 设定采样速率, 即每一通道每秒采样点数
    # USB-205最高为500000
    rate = 50000

    # 各通道采样点数，用于计算平均强度
    # 采样点数越多，噪声抑制效果越好，但数据采集时间越长
    points_per_channel = 1000

    # 利用两个通道分别采集两个波长的光强集号
    low_chan = 0  # 1550 nm
    high_chan = 1  # 1362 nm

    num_chans = high_chan - low_chan + 1
    total_count = points_per_channel * num_chans

    # 设定采集参数
    scan_options = ScanOptions.FOREGROUND
    scan_options |= ScanOptions.SCALEDATA

    #########################################################
    # 打开并设置MCC DAQ设备
    #########################################################
    board_num = 0
    config_first_detected_device(board_num)

    # 查询采集卡所支持的参数
    daq_dev_info = DaqDeviceInfo(board_num)

    ai_info = daq_dev_info.get_ai_info()
    ai_range = ai_info.supported_ranges[0]

    if high_chan > ai_info.num_chans - 1:
        ul.release_daq_device(board_num)
        raise Exception("Error: Too much channels")

    ###############################################################
    # 设定采集卡数字输入输出端口DIO为数字输出，用于控制探测器的增益
    ###############################################################
    # Find the first port that supports output, defaulting to None
    # if one is not found.
    dio_info = daq_dev_info.get_dio_info()
    port = next((port for port in dio_info.port_info if port.supports_output), None)
    if not port:
        ul.release_daq_device(board_num)
        raise Exception("Error: The DAQ device does not support digital output")

    # If the port is configurable, configure it for output.
    if port.is_port_configurable:
        ul.d_config_port(board_num, port.type, DigitalIODirection.OUT)

    #########################################################
    # 分配内存空间用于暂存采集数据
    #########################################################
    memhandle = None
    memhandle = ul.scaled_win_buf_alloc(total_count)
    if not memhandle:
        ul.release_daq_device(board_num)
        raise Exception("Error: Failed to allocate memory")

    ctypes_array = cast(memhandle, POINTER(c_double))


    #########################################################
    # 定义数据采集函数
    #########################################################
    def data_acquire(tnum=10):
        # tnum 为重复测量次数，通过多次测量去除探测器噪声
        mean_data = np.zeros((tnum, num_chans))  # 初始化测量数据数组
        cdata = np.zeros((points_per_channel, num_chans))  # 暂存当前测量数据

        for i in range(tnum):
            # data collection
            ul.a_in_scan(
                board_num,
                low_chan,
                high_chan,
                total_count,
                rate,
                ai_range,
                memhandle,
                scan_options,
            )

            # Transform data to a numpy array
            cdata = np.ctypeslib.as_array(ctypes_array, (total_count,)).reshape(
                (points_per_channel, num_chans)
            )

            mean_data[i, :] = cdata.mean(axis=0)

        # 返回各通道的重复均值
        return mean_data.mean(axis=0)


    #########################################################
    # 初始化测量标记和数组存储数组
    #########################################################
    gain_num = 8
    signal = np.ones((gain_num, num_chans)) * 10  # 存储各个增益下的平均信号

    # 增益序列, 通过digital out的前六个比特位来调整探测器增益
    # 通过DIO0,DIO1,DIO2三个比特位来控制0通道的探测器增益
    # 通过DIO3,DIO4,DIO5三个比特位来控制1通道的探测器增益
    gain_value = np.array(
        [[0, 1, 2, 3, 4, 5, 6, 7], [0, 8, 16, 24, 32, 40, 48, 56]]
    )
    gain_value = gain_value.T

    print("————————测量开始前，两通道光信号均需处于关闭状态————————")
    # play_music("music/1.mp3", loop=False)
    # time.sleep(5.2)
    # 监测两个通道光强信号，测量开始前两路均处于关闭
    ul.d_out(board_num, port.type, 63)
    mear_ch_flag = data_acquire(tnum=2) > th
    n1 = 1
    print(">>>>>>>>请关闭两通道光信号!!!<<<<<<<<<")
    while True:
        if n1 == 1:
            play_music("music/2.mp3")
            n1 = 0
        if np.all(np.logical_not(mear_ch_flag)):
            stop_music()
            break
        mear_ch_flag = data_acquire(tnum=2) > th

    print("————————————请仅打开一路光信号，进行信号采集——————————————————")
    mear_ch_flag = data_acquire(tnum=2) > th
    n2 = 1
    while True:
        if n2 == 1:
            play_music("music/3.mp3")
            n2 = 0
        if np.any(mear_ch_flag):
            if not np.all(np.logical_not(mear_ch_flag)):
                stop_music()
                break
        data_num = data_acquire(tnum=2)
        mear_ch_flag = data_num > th
        print(data_num)

    ul.d_out(board_num, port.type, 0)
    gain_value_list = gain_value[:, mear_ch_flag].squeeze()
    print("——————信号采集开始——————")
    play_music("music/4.mp3", loop=False)
    time.sleep(2)
    for num, port_value in enumerate(gain_value_list):
        # Output the value to the port
        ul.d_out(board_num, port.type, port_value)
        print(f"探测器增益{num * 10} dB, 信号采集")
        value = data_acquire()[mear_ch_flag].squeeze()
        print(value)
        signal[num][mear_ch_flag] = value if value > 0 else 0
        if value * 3 > 9.5:
            break
    print("本路采集完成，请关闭该路光信号")
    play_music("music/5.mp3", loop=False)
    # time.sleep(4)
    time.sleep(1.7)

    if args.num_laser == 1:
        print("两路信号均已采集完毕")
        # play_music("music/8.mp3", loop=False)
        # time.sleep(3)
        ul.d_out(board_num, port.type, 0)
        # release DAQ device
        ul.win_buf_free(memhandle)
        ul.release_daq_device(board_num)

        # 存储采集到的信号
        fold_path = os.path.join("Absolute_Data", group, date)
        get_path(fold_path)

        files = os.listdir(fold_path)
        signal[:, [0, 1]] = signal[:, [1, 0]]

        if f"{concentration:.3f}_{group}.csv" in files:
            df = pd.DataFrame(signal.ravel(order="F"))
            df.to_csv(os.path.join(fold_path, f"{concentration:.3f}_wrong.csv"), header=False)
            play_music("music/7.mp3")
            time.sleep(2.3)
            raise Exception("文件夹命名错误！！！！")
        else:
            df = pd.DataFrame(signal.ravel(order="F"))
            df.to_csv(os.path.join(fold_path, f"{concentration:.3f}_{group}.csv"), header=False)
        sys.exit()

    # # 修改
    ul.d_out(board_num, port.type, 63)
    middle_ch_flag = data_acquire(tnum=2) > th
    n3 = 1
    print(">>>>>>>>请关闭两通道光信号!!!<<<<<<<<<")
    while True:
        if n3 == 1:
            play_music("music/2.mp3")
            n3 = 0
        if np.all(np.logical_not(middle_ch_flag)):
            stop_music()
            break
        middle_ch_flag = data_acquire(tnum=2) > th

    if mear_ch_flag[0]:
        ul.d_out(board_num, port.type, 56)
    else:
        ul.d_out(board_num, port.type, 7)
    new_ch_flag = data_acquire(tnum=2) > th
    n4 = 1
    print("请打开另一路光信号，进行信号采集")
    while True:
        if n4 == 1:
            play_music("music/6.mp3")
            n4 = 0
        if np.all(new_ch_flag == np.logical_not(mear_ch_flag)):
            stop_music()
            break
        # time.sleep(0.1)
        data_num = data_acquire(tnum=2)
        new_ch_flag = data_num > th
        print(data_num)

    ul.d_out(board_num, port.type, 0)
    gain_value_list = gain_value[:, new_ch_flag].squeeze()
    print("——————信号采集开始——————")
    play_music("music/4.mp3", loop=False)
    time.sleep(2)
    for num, port_value in enumerate(gain_value_list):
        # Output the value to the port
        ul.d_out(board_num, port.type, port_value)
        print(f"探测器增益{num * 10} dB, 信号采集")
        value = data_acquire()[new_ch_flag].squeeze()
        print(value)
        signal[num][new_ch_flag] = value if value > 0 else 0
        if value * 3 > 9.5:
            break
    print("本路采集完成，请关闭该路光信号")
    play_music("music/5.mp3", loop=False)
    # time.sleep(4)
    time.sleep(1.7)
    print("两路信号均已采集完毕")
    # play_music("music/8.mp3", loop=False)
    # time.sleep(3)
    ul.d_out(board_num, port.type, 0)
    # release DAQ device
    ul.win_buf_free(memhandle)
    ul.release_daq_device(board_num)

    # 存储采集到的信号
    fold_path = os.path.join("Absolute_Data", group, date)
    get_path(fold_path)

    files = os.listdir(fold_path)
    signal[:, [0, 1]] = signal[:, [1, 0]]

    if f"{concentration:.3f}_{group}.csv" in files:
        df = pd.DataFrame(signal.ravel(order="F"))
        df.to_csv(os.path.join(fold_path, f"{concentration:.3f}_wrong.csv"), header=False)
        play_music("music/7.mp3")
        time.sleep(2.3)
        raise Exception("文件夹命名错误！！！！")
    else:
        df = pd.DataFrame(signal.ravel(order="F"))
        df.to_csv(os.path.join(fold_path, f"{concentration:.3f}_{group}.csv"), header=False)
