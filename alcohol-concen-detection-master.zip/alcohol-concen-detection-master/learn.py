# # 批量更改文件名
# import os
#
# path = "Absolute_Data/3_1/06-07_1"
# files = os.listdir(path)
#
# for file in files:
#     old_name = path + os.sep + file
#     new_name = path + os.sep + "{}_3_1.csv".format(file[:-6])
#     os.rename(old_name, new_name)


# import numpy as np
#
# # # 数据预处理
# # import os
# #
# # import shutil
# #
# # from utils.data_loading_utils import data_process, data_iter
# #
# # a, b, c, d = 0, 8, 8, 13
# # chan_0_num = "{}:{}".format(a, b)
# # chan_1_num = "{}:{}".format(c, d)
# # train_groups = "1_1+1_2"
# # test_groups = "1_3+3_1"
# # process = True
# # if process:
# #     net_train_path = "Relative_Data/train"
# #     shutil.rmtree(net_train_path)
# #     for train_group in train_groups.split('+'):
# #         data_train_path = "Absolute_Data/{}".format(train_group)
# #         data_process(data_train_path, net_train_path, a, b, c, d)
# #
# #     net_test_path = "Relative_Data/test"
# #     shutil.rmtree(net_test_path)
# #     for test_group in test_groups.split('+'):
# #         data_test_path = "Absolute_Data/{}".format(test_group)
# #         data_process(data_test_path, net_test_path, a, b, c, d)
#
# # # 播放语音
# # from playsound import playsound
# #
# # path = "music/1.mp3"
# # for i in range(7):
# #     playsound("music/{}.mp3".format(i+1))
#
# # #批量处理文件数据
# # train_groups = "1_1+1_2+1_3+3_1"
# # for train_group in train_groups.split('+'):
# #     data_train_path = "Absolute_Data/{}".format(train_group)
# #     print(data_train_path)
#
# # import json
# #
# # dict1 = {'a': 1, 'b': 2, 'c': 3}
# # dict2 = {'A': 1, 'B': 2, 'C': 3}
# # dict3 = {'q': 1, 'b': 2, 'z': 3}
# # dict_list = []
# # dict_list.append(dict1)
# # dict_list.append(dict2)
# # dict_list.append(dict3)
# # # 其实，我完全可以这样写dict_list = [dict1，dict2，dict3]；之所如上述那么些，是让大家知道，我们是动态控制的
# # with open('demo3.json', mode='w', encoding='utf-8') as f:
# #     json.dump(dict_list, f)
# #     # 将字典列表存入json文件中
# #
# # with open('demo3.json', mode='r', encoding='utf-8') as f:
# #     dicts = json.load(f)
# #     # 将多个字典从json文件中读出来
# #     for i in dicts:
# #         print(i)
#
# # dict = {'chan_0': {'a': 1, 'b': 2}, 'chan_1': {'c': 3, 'd': 4}}
# #
# # filename = open('list.txt', 'w')  # dict转txt
# # for k, v in dict.items():
# #     filename.write(k + ':' + str(v))
# #     filename.write('\n')
# # filename.close()
#
# # #字典嵌套保存
# # import json
# #
# # filename = open('new.json', 'r')
# # a = filename.read()
# # a = json.loads(a)
# # a['m'] = {'a': 1, 'd': 2}
# #
# # a = json.dumps(a, indent=4)
# # filename = open('new.json', 'w')
# # filename.write(a)
# # filename.close()
#
#
# # # 二位列表添加元素
# # import numpy as np
# #
# # a = [[], [], [], [], []]
# # t = 0
# # for i in range(4):
# #     for j in range(5):
# #         if t==0:
# #             a[t].append(t+1)
# #         a[t+1].append(j)
# #     t += 1
# # print(np.array(a).shape)
# # print(np.array(a))
#
# # # 制作表格
# # from tabulate import tabulate
# #
# # info = {'First Name': ['John', 'Mary', 'Jennifer'],
# # 'Last Name': ['Smith', 'Jane', 'Doe'],
# # 'Age': [39, 25, 28]}
# #
# # print(tabulate(info, headers='keys', tablefmt='fancy_grid'))
#
# ##画表格
# # import pandas as pd
# # import matplotlib.pyplot as plt
# # import matplotlib
# # matplotlib.rc("font",family='YouYuan')
# #
# # # 创建一个DataFrame
# # data = {'姓名': ['小明', '小红', '小李'],
# #         '年龄': [20, 25, 30],
# #         '城市': ['北京', '上海', '广州']}
# # df = pd.DataFrame(data)
# #
# # # 创建一个表格图片
# # fig, ax = plt.subplots()
# # ax.axis('off')  # 隐藏坐标轴
# #
# # table = ax.table(cellText=df.values, colLabels=df.columns, cellLoc='center', loc='center')
# #
# #
# # table.auto_set_font_size(False)
# # table.set_fontsize(14)
# # table.scale(1.2, 1.5)  # 调整表格大小
# #
# #
# # # plt.savefig('table.png')  # 保存表格图片
# # plt.show()
#
# ## 协程编程
# # import pygame
# # import asyncio
# # import time
# #
# # pygame.init()
# # pygame.mixer.init()
# #
# #
# # async def play_music(file_path, loop=True)->None:
# #     pygame.mixer.music.load(file_path)
# #     pygame.mixer.music.play(loops=-1 if loop else 0)
# #     time.sleep(3)
# #
# # async def stop_music():
# #     pygame.mixer.music.stop()
# #
# #
# # file_path = "music\\4.mp3"
# # # start = time.time()
# # # playsound(file_path)
# # # end = time.time()
# # # print("播放时间：{}".format(end-start))
# #
# # asyncio.run(play_music(file_path))
# # # time.sleep(2)
# # i = 0
# # while i < 3:
# #     i += 1
# #     time.sleep(1)
# # asyncio.run(stop_music())
#
# # import asyncio
# # import pygame
# # import time
# # from asyncio import CancelledError
# #
# # pygame.init()
# # pygame.mixer.init()
# #
# #
# # async def play_music(file_path, loop=True) -> None:
# #     pygame.mixer.music.load(file_path)
# #     pygame.mixer.music.play(loops=-1 if loop else 0)
# #     await asyncio.sleep(3)
# #
# #
# # async def stop_music():
# #     pygame.mixer.music.stop()
# #
# #
# # async def call_api(message, result=1000, delay=3):
# #     print(message)
# #     await asyncio.sleep(delay)
# #     return result
# #
# #
# # async def main():
# #     task1 = asyncio.create_task(play_music("music\\4.mp3"))
# #     # task2 = asyncio.create_task(play_music("music\\2.mp3"))
# #     start = time.perf_counter()
# #
# #     await task1
# #     time.sleep(5)
# #     print(task1.done())
# #     task1.cancel()
# #     print(task1.done())
# #     try:
# #         await task1
# #     except CancelledError:
# #         print('Task has been cancelled.')
# #     n = 10
# #     while n > 1:
# #         time.sleep(1)
# #         print(n)
# #         if n == 5:
# #             task1.cancel()
# #         n -= 1
# #
# #     end = time.perf_counter()
# #     print(f'It took {round(end - start, 0)} second(s) to complete.')
# #
# #
# # asyncio.run(main())
#
# # import numpy as np
# # # import seaborn as sns
# # import matplotlib.pyplot as plt
# #
# # size = 3
# # x = np.arange(size)
# # a = [5, 10, 23]
# # a_SD = [1.1, 0.6, 1.4]
# # b = [6, 9, 10]
# # b_SD = [0.4, 1.2, 2.5]
# #
# # total_width, n = 0.6, 2
# # width = total_width / n
# # x = x - (total_width - width) / 2
# # labels = ['Treat1', 'Treat2', 'Treat3']
# #
# # plt.bar(x, a, width=width, yerr=a_SD, tick_label=labels, label='Control')
# # plt.plot(x, )
# # plt.bar(x + width, b, width=width, yerr=b_SD, tick_label=labels, label='Experimental')
# #
# # plt.legend()
# # plt.show()
#
# # sns.set_theme(style="whitegrid")
# # tips = sns.load_dataset("tips")
# # ax = sns.barplot(x="day", y="tip", data=tips, capsize=.2)
#
# import matplotlib.pyplot as plt
#
# x = [1, 2, 3, 4, 5]
# # 数据集
# y = [20, 44, 21, 64, 46]
# # 误差列表
# std_err = [1, 2, 5, 3, 2]
#
# error_params = dict(elinewidth=4, ecolor='coral', capsize=5)  # 设置误差标记参数
# # 绘制柱状图，设置误差标记以及柱状图标签
# plt.bar(x, y, color=['b', 'g', 'yellow', 'orange', 'gray'], yerr=std_err, error_kw=error_params,
#         tick_label=['blue', 'green', 'yellow', 'orange', 'gray'])
# # 显示图形
# plt.show()

s2 = "0.450_7_3.csv"
print(s2[5:])
s = "0.300_2_2.csv"
print(s[:-4])
s1 = "Absolute_Data/1_1"
print(s1[-3:])

# import torch
#
# print(torch.cuda.is_available())

# import wx
#
#
# class MyFrame(wx.Frame):
#     def __init__(self):
#         super().__init__(None, title="第一个python程序", size=(400, 300), pos=(100, 100))
#         panel = wx.Panel(parent=self)
#         self.statictext = wx.StaticText(parent=panel, label="请单击OK！", pos=(110, 20))
#         b1 = wx.Button(parent=panel, id=10, label="Button1")
#         b2 = wx.Button(parent=panel, id=11, label="Button2")
#
#         hbox = wx.BoxSizer(wx.HORIZONTAL)
#         hbox.Add(b1, proportion=1, flag=wx.EXPAND | wx.ALL, border=10)
#         hbox.Add(b2, proportion=1, flag=wx.EXPAND | wx.ALL, border=10)
#         vbox = wx.BoxSizer(wx.VERTICAL)
#         vbox.Add(self.statictext, proportion=1, flag=wx.CENTER | wx.FIXED_MINSIZE | wx.TOP, border=10)
#         vbox.Add(hbox, proportion=1, flag=wx.CENTER)
#         panel.SetSizer(vbox)
#
#         self.Bind(wx.EVT_BUTTON, self.on_click, id=10, id2=20)
#
#     def on_click(self, event):
#
#         event_id = event.GetId()
#
#         print(event_id)
#         if event_id == 10:
#             self.statictext.SetLabelText("单击Button1")
#         else:
#             self.statictext.SetLabelText("单击Button2")
#
#
# app = wx.App()
#
# frm = MyFrame()
#
# frm.Show()
#
# app.MainLoop()
